# Chapter 1 Source Registry

Access date for all web sources: 2026-08-12.

## Primary implementation authority

- Source: Author-provided implementation audit based on direct source-code inspection
- Date received: 2026-08-12
- External URL: None; internal project evidence
- Priority: Primary authority for implemented, partially implemented and absent technical functions
- Used in: Sections 1.1.5, 1.2.3--1.2.4, 1.3.3, 1.4 and 1.5
- Information extracted: Runtime components, capture timing, authentication boundaries, privacy paths, offline behaviour, mission generation, parent-dashboard form and implementation limitations
- Rule applied: When project documentation and source-code behaviour differ, Chapter 1 uses the implementation-audit result and states the distinction when it affects project scope.

## External sources

### WEB-001
- Organization: Lezarts.Digital
- Title: Notre agence digitale
- URL: https://lezarts.digital/qui-sommes-nous/
- Used in: Sections 1.1.1 and 1.1.2
- Information extracted: Company identity, Tunis location, operation since 2012, and current service categories.

### WEB-002
- Organization: Lezarts.Digital
- Title: Solutions digitales
- URL: https://lezarts.digital/service/solutions-digitales/
- Used in: Sections 1.1.2--1.1.4 and Table 1.1
- Information extracted: Web, mobile and related digital-solution services.

### WEB-003
- Organization: Lezarts.Digital
- Title: Design
- URL: https://lezarts.digital/service/design/
- Used in: Section 1.1.3 and Table 1.1
- Information extracted: Design and user-experience activity area.

### WEB-004
- Organization: Lezarts.Digital
- Title: Marketing digital
- URL: https://lezarts.digital/service/marketing-digital/
- Used in: Section 1.1.3 and Table 1.1
- Information extracted: Digital-marketing activity area.

### WEB-005
- Organization: Lezarts.Digital
- Title: R\'egie
- URL: https://lezarts.digital/service/regie/
- Used in: Sections 1.1.1--1.1.3 and Table 1.1
- Information extracted: Outsourcing and resource-support services, including web and mobile assignments.

### WEB-006
- Organization: American Academy of Pediatrics
- Title: Screen Time Guidelines
- URL: https://www.aap.org/en/patient-care/media-and-children/center-of-excellence-on-social-media-and-youth-mental-health/qa-portal/qa-portal-library/qa-portal-library-questions/screen-time-guidelines/
- Used in: Section 1.2.1
- Information extracted: Guidance to assess screen use beyond a single universal duration threshold.

### WEB-007
- Organization: American Academy of Pediatrics
- Title: The 5 Cs of Media Use
- URL: https://www.aap.org/en/patient-care/media-and-children/center-of-excellence-on-social-media-and-youth-mental-health/5cs-of-media-use/
- Used in: Section 1.2.1
- Information extracted: Child, Content, Calm, Crowding Out and Communication framework.

### WEB-008
- Authors: Sumudu Mallawaarachchi et al.
- Title: Early Childhood Screen Use Contexts and Cognitive and Psychosocial Outcomes: A Systematic Review and Meta-analysis
- URL: https://jamanetwork.com/journals/jamapediatrics/fullarticle/2821940
- Used in: Section 1.2.1
- Information extracted: Evidence that content, purpose, co-use and other contextual factors should be considered alongside total screen time.

### WEB-009
- Organization: Google
- Title: Manage your child's screen time
- URL: https://support.google.com/families/answer/7103340?hl=en
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Family Link daily limits, schedules, bonus time and device locking.

### WEB-010
- Organization: Google
- Title: Set app time limits on your child's device
- URL: https://support.google.com/families/answer/15957417?hl=en
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Per-application time limits in Family Link.

### WEB-011
- Organization: Google
- Title: Manage your child's Google Account with Family Link
- URL: https://support.google.com/families/answer/7103262?hl=en
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Access to child-account activity through Family Link controls.

### WEB-012
- Organization: Google
- Title: Chrome and your child's Google Account
- URL: https://support.google.com/families/answer/7087030?hl=en
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Chrome website filtering, allow/block lists and approval requests.

### WEB-013
- Organization: Google
- Title: How to set up content restrictions on Google Play
- URL: https://support.google.com/families/answer/1075738?hl=en
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Google Play content restrictions for supervised family members.

### WEB-014
- Organization: Apple
- Title: Use Screen Time to manage your child's iPhone or iPad
- URL: https://support.apple.com/en-us/108806
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Activity summaries, limits, downtime, exception requests and Communication Safety.

### WEB-015
- Organization: Apple
- Title: Use parental controls to manage your child's iPhone or iPad
- URL: https://support.apple.com/en-au/105121
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Application, purchase, content-rating, web-content and privacy restrictions.

### WEB-016
- Organization: Microsoft
- Title: Set screen time limits across devices
- URL: https://support.microsoft.com/en-us/family-safety/set-screen-time-limits-across-devices
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Family Safety screen-time schedules and platform scope.

### WEB-017
- Organization: Microsoft
- Title: Set app and game limits
- URL: https://support.microsoft.com/en-us/family-safety/set-app-and-game-limits
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Application and game time limits.

### WEB-018
- Organization: Microsoft
- Title: View device and app use with Family Safety activity reporting
- URL: https://support.microsoft.com/en-us/family-safety/view-device-and-app-use-with-family-safety-activity-reporting
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: App, game, screen-time, web and search reporting, including Edge dependency.

### WEB-019
- Organization: Microsoft
- Title: Filter websites and searches using Microsoft Family Safety
- URL: https://support.microsoft.com/en-us/family-safety/filter-websites-and-searches-using-microsoft-family-safety
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Website/search filtering and Microsoft Edge dependency.

### WEB-020
- Organization: Qustodio
- Title: What is Qustodio and what can I do with it?
- URL: https://help.qustodio.com/hc/en-us/articles/360005215597-What-is-Qustodio-and-what-can-I-do-with-it
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Activity summaries, app monitoring, limits, website blocking, alerts and multi-platform supervision.

### WEB-021
- Organization: Qustodio
- Title: How to set time limits with Qustodio
- URL: https://help.qustodio.com/hc/en-us/articles/360005216797-How-to-set-time-limits-with-Qustodio
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Daily limits, screen-free schedules and internet pausing.

### WEB-022
- Organization: Qustodio
- Title: How do I block or allow websites using Qustodio?
- URL: https://help.qustodio.com/hc/en-us/articles/360005216737-How-do-I-block-or-allow-websites-using-Qustodio
- Used in: Sections 1.3.1 and 1.3.3
- Information extracted: Category-based and URL-specific website filtering.

### WEB-023
- Organization: IBM
- Title: Agile vs. Waterfall: What's the Difference?
- URL: https://www.ibm.com/think/topics/agile-vs-waterfall
- Used in: Section 1.5.1 and Table 1.4
- Information extracted: Sequential characteristics and appropriate context of Waterfall development.

### WEB-024
- Authors: Kevin Forsberg and Harold Mooz
- Title: The Relationship of System Engineering to the Project Cycle
- URL: https://www.semanticscholar.org/paper/The-Relationship-of-System-Engineering-to-the-Cycle-Forsberg-Mooz/f65766aadb4aaf54f41edde0f6ffc36f576e0afc
- Used in: Section 1.5.1 and Table 1.4
- Information extracted: Relationship between project definition and verification/validation represented by the V-model.

### WEB-025
- Authors: Agile Manifesto signatories
- Title: Manifesto for Agile Software Development
- URL: https://agilemanifesto.org/
- Used in: Section 1.5.1 and Table 1.4
- Information extracted: Agile values concerning working software, collaboration and response to change.

### WEB-026
- Authors: Ken Schwaber and Jeff Sutherland
- Title: The Scrum Guide
- URL: https://scrumguides.org/docs/scrumguide/v2020/2020-Scrum-Guide-US.pdf
- Used in: Sections 1.5.1 and 1.5.2 and Table 1.4
- Information extracted: Scrum's iterative, incremental approach and inspection/adaptation principles.

## Project sources

### PROJECT-001
- Author: Helmi Megdiche
- Title: SafeGuard Project Repository
- URL: https://github.com/Helmi-Megdiche/PFE
- Used in: Section 1.1.5
- Information extracted: Project source and documentation inventory.

### PROJECT-002
- Author: Helmi Megdiche
- Title: SafeGuard Software Requirements Specification
- URL: https://github.com/Helmi-Megdiche/PFE/blob/main/docs/SRS.md
- Used in: Sections 1.1.5, 1.2.3--1.2.4, 1.3.3 and 1.4
- Information extracted: Implemented functions, actors, subsystem scope, privacy principle and exclusions.

### PROJECT-003
- Author: Helmi Megdiche
- Title: SafeGuard Architecture
- URL: https://github.com/Helmi-Megdiche/PFE/blob/main/docs/architecture.md
- Used in: Sections 1.1.5, 1.2.4 and 1.4
- Information extracted: High-level subsystem organization and responsibilities.

### PROJECT-004
- Author: Helmi Megdiche
- Title: Scrum Artefacts -- SafeGuard AI Parental Control Platform
- URL: https://github.com/Helmi-Megdiche/PFE/blob/main/docs/scrum_artifacts.md
- Used in: Sections 1.1.5, 1.4.4 and 1.5.3--1.5.4
- Information extracted: Solo-Scrum organization, artifacts, Sprint duration and iterative work process.

### PROJECT-005
- Author: Helmi Megdiche
- Title: SafeGuard Pre-Final Technical Report
- URL: https://github.com/Helmi-Megdiche/PFE/blob/main/docs/PREFINAL_REPORT.md
- Used in: Sections 1.2.3--1.2.4, 1.3.3 and 1.4
- Information extracted: High-level project goals, delivered workflow, privacy approach and system limitations.